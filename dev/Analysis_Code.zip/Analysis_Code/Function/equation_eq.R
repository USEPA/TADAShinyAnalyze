### This script applies equation

